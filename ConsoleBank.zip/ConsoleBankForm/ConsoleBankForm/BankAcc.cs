﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBankForm
{
    class BankAcc
    {
        private string accNo;
        private string accHolder;
        private double accBalance;

        public BankAcc(string accNo, string accHolder, double accBalance)
        {
            this.accNo = accNo;
            this.accHolder = accHolder;
            this.accBalance = accBalance;
        }

        public double Deposit(double amount)
        {
            accBalance += amount;
            return accBalance;
        }

        public double Withdraw(double amount)
        {
            if (accBalance >= amount)
            {
                accBalance -= amount;
            }
            else
                accBalance = 0;
            return accBalance;
        }

        public double Display()
        {
            return accBalance;
        }
    }
}

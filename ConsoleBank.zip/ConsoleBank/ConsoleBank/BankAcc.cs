﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBank
{
    class BankAcc
    {
        private string accNo;
        private string accHolder;
        private double accBalance;

        public BankAcc(string accNo, string accHolder, double accBalance)
        {
            this.accNo = accNo;
            this.accHolder = accHolder;
            this.accBalance = accBalance;
        }

        public void Deposit(double amount)
        {
            accBalance += amount;
            Console.WriteLine(accBalance);
        }

        public void Withdraw(double amount)
        {
            if (accBalance >= amount)
            {
                accBalance -= amount;
            }
            else
                accBalance = 0;
            Console.WriteLine(accBalance);
        }

        public void Display()
        {
            Console.WriteLine("The current balance: " + accBalance);
            Console.ReadLine();
        }
    }
}

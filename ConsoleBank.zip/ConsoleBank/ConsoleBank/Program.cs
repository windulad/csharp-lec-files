﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using ConsoleBank.BankAcc;

namespace ConsoleBank
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAcc acc = new BankAcc("2345156", "Dee Perera", 15000.00);
            acc.Deposit(5000.00);
            acc.Withdraw(1000.00);
            acc.Display();
        }
    }
}

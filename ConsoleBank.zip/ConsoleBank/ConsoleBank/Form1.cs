﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleBank
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            string AccNo = txtAccNo.Text;
            string AccHolder = txtAccHolder.Text;
            double Balance = double.Parse(txtBalance.Text);
            double Deposit = double.Parse(txtDeposit.Text);
            double Withdraw = double.Parse(txtWithdraw.Text);

            BankAcc acc = new BankAcc(AccNo, AccHolder, Balance);
            acc.Deposit(Deposit);
            acc.Withdraw(Withdraw);

            //txtCurBalance.Text = acc.Display();
        }
    }
}
